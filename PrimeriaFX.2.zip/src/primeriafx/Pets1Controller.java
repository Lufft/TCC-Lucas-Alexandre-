/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */
public class Pets1Controller implements Initializable{
    
    public double calculaConsumoRacao(double peso, double precoRacao){
        double consumoMensal = 0;
        if(peso < 6.8){
            consumoMensal = (1.5*precoRacao) + 180;
        }else if(peso > 6.8 && peso < 9.1 ){
            consumoMensal = (9*precoRacao) + 120;
        }else if (peso > 9.1){ 
            consumoMensal = (15*precoRacao) + 140;
        }
            return consumoMensal;
    }
    public void limparText(TextField campo){
        campo.setText("");
    }
    public void limparLabel(Label label){
        label.setText("");
    }
    
    @FXML private Button voltarButton;
    @FXML private TextField peso;
    @FXML private TextField frequencia;
    @FXML private TextField precoFilhote;
    @FXML private TextField precoRacao;
    @FXML private Label mensal;
    @FXML private Label primeiroAno;
    @FXML private Label gastoAnual;
    @FXML private Label total;
    @FXML private CheckBox castracao;
    @FXML private Pane painel;
    @FXML private Pane painel1;

@FXML   private void voltar(ActionEvent e) throws IOException{
        Parent tela_principal_parent = FXMLLoader.load(getClass().getResource("Economia1.fxml"));
        Scene tela_principal_scene = new Scene(tela_principal_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(tela_principal_scene);
        app_stage.show();
    }
    
@FXML  private void calcular(ActionEvent e) throws IOException{
        double consumo = calculaConsumoRacao(Double.parseDouble(peso.getText()), Double.parseDouble(precoRacao.getText()));
        double consumoAno = consumo*12;
        double primeiroAnoTotal = Double.parseDouble(precoFilhote.getText() + 200 + consumoAno);
        double totalTudo = (consumoAno*7) + primeiroAnoTotal;
        painel1.setVisible(false);
        painel.setVisible(true);
        mensal.setText(String.valueOf(consumo));
        gastoAnual.setText(String.valueOf(consumoAno));
        primeiroAno.setText(String.valueOf(primeiroAnoTotal));
        total.setText(String.valueOf(totalTudo));
    }
@FXML private void limparCampos(ActionEvent e) throws IOException{
    limparLabel(mensal);
    limparLabel(primeiroAno);
    limparLabel(gastoAnual);
    limparLabel(total);
    limparText(peso);
    limparText(frequencia);
    limparText(precoFilhote);
    limparText(precoRacao);
    painel.setVisible(false);
    painel1.setVisible(true);
}
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}