/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.awt.Panel;
import javafx.fxml.FXML;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import primeriafx.atributosTaxi.MetodosTaxi;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */
public class TaxiCarro2Controller implements Initializable {
    @FXML TextField ipva;
    @FXML TextField kilometragem;
    @FXML TextField precoCarro;
    @FXML TextField precoGaso;
    @FXML TextField precoKmTaxi;
    @FXML TextField bandeirada;
    @FXML TextField depreciacao;
    @FXML TextField manuntencao;
    @FXML TextField seguro;
    @FXML TextField emplacamento;    
    @FXML Label campoFinalTaxi;
    @FXML Label campoFinalCarro;
    @FXML Panel painel;
    
    public void btn(ActionEvent e)throws IOException{
        painel.setVisible(true);
        MetodosTaxi met = new  MetodosTaxi();
    double valorIpva = met.calculaIPVA(Double.parseDouble(precoCarro.getText()),
            Integer.parseInt(ipva.getText()));
    double valorseguro = met.calculaSeguro(Double.parseDouble(precoCarro.getText()),
            Integer.parseInt(seguro.getText()));
    double valorEmplacamento = met.calculaEmplacamento(Double.parseDouble(precoCarro.getText()),
            Integer.parseInt(emplacamento.getText()));
    double valorConsumoCarro = met.valorAnualGasolina(Double.parseDouble(precoGaso.getText()),
            Integer.parseInt(kilometragem.getText()),Double.parseDouble(precoCarro.getText()));
    double valorConsumoTaxi = met.valorAnualTaxi(Double.parseDouble(precoKmTaxi.getText()),Integer.parseInt(kilometragem.getText()),
            Double.parseDouble(bandeirada.getText()));
    double valorDepreciaçao = met.calculaDepreciacao(Double.parseDouble(precoCarro.getText()), Integer.parseInt(depreciacao.getText()));
    
    double consumoGeralCarro = valorIpva+valorseguro+valorEmplacamento+valorConsumoCarro+ valorDepreciaçao +Double.parseDouble(manuntencao.getText());
    campoFinalCarro.setText(String.valueOf(consumoGeralCarro));
    campoFinalTaxi.setText(String.valueOf(valorConsumoTaxi));
    }
    @FXML private void fecharPainel(ActionEvent e ) throws IOException{
        painel.setVisible(false);
    }

    @FXML private void voltar(ActionEvent e) throws IOException{
        Parent economia_parent = FXMLLoader.load(getClass().getResource("Economia1.fxml"));
        Scene economia_scene = new Scene(economia_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(economia_scene);
        app_stage.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
