/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */
public class TelaPrincipalController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private void irTelaEconomia1(ActionEvent e) throws IOException{
        Parent economia1_parent = FXMLLoader.load(getClass().getResource("Economia1.fxml"));
        Scene economia1_scene = new Scene(economia1_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(economia1_scene);
        app_stage.show();
    }
    @FXML
    private void irTelaInvestimentos(ActionEvent e) throws IOException{
        Parent investimento1_parent = FXMLLoader.load(getClass().getResource("Investimento1.fxml"));
        Scene investimento1_scene = new Scene(investimento1_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(investimento1_scene);
        app_stage.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
