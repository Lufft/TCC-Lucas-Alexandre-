package primeriafx.atributosTaxi;
/**
 *
 * @author Alexandre
 */
public class Atributos {
	private double precoCarro;
	private double precoGaso;
	private int ipva;
	private int kilometragem;
	private double precoKmTaxi;
	private double bandeirada;
	private int depreciacao;
	private int seguro;
	private double manuntencao;
	private int emplacamento;
	
	public int getEmplacamento() {
		return emplacamento;
	}
	public void setEmplacamento(int emplacamento) {
		this.emplacamento = emplacamento;
	}
	public int getDepreciacao() {
		return depreciacao;
	}
	public void setDepreciacao(int depreciacao) {
		this.depreciacao = depreciacao;
	}
	public int getSeguro() {
		return seguro;
	}
	public void setSeguro(int seguro) {
		this.seguro = seguro;
	}
	public double getManuntencao() {
		return manuntencao;
	}
	public void setManuntencao(double manuntencao) {
		this.manuntencao = manuntencao;
	}
	public double getBandeirada() {
		return bandeirada;
	}
	public void setBandeirada(double bandeirada) {
		this.bandeirada = bandeirada;
	}
	public double getPrecoCarro() {
		return precoCarro;
	}
	public void setPrecoCarro(double precoCarro) {
		this.precoCarro = precoCarro;
	}
	public double getPrecoGaso() {
		return precoGaso;
	}
	public void setPrecoGaso(double precoGaso) {
		this.precoGaso = precoGaso;
	}
	public int getIpva() {
		return ipva;
	}
	public void setIpva(int ipva) {
		this.ipva = ipva;
	}
	public int getKilometragem() {
		return kilometragem;
	}
	public void setKilometragem(int kilometragem) {
		this.kilometragem = kilometragem;
	}
	public double getPrecoKmTaxi() {
		return precoKmTaxi;
	}
	public void setPrecoKmTaxi(double precoKmTaxi) {
		this.precoKmTaxi = precoKmTaxi;
	}		
}

