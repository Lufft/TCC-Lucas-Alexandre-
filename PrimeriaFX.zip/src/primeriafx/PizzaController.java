package primeriafx;

import java.net.URL;
import static java.util.Collections.list;

import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.PieChart.Data;
import javafx.scene.control.Label;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

public class PizzaController implements Initializable {
    @FXML PieChart pie;
    @FXML Label label;

    public void btn(ActionEvent event) {
        ObservableList<Data> list = FXCollections.observableArrayList(
                new PieChart.Data("DJABO", 20),
                new PieChart.Data("BRUCE", 10),
                new PieChart.Data("EPITACIO", 45),
                new PieChart.Data("MR BEAN", 15),
                new PieChart.Data("JOCIMAELCIMA", 10)
        );
        pie.setData(list);

        for (final PieChart.Data data : pie.getData()) {
            data.getNode().addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>(){
                @Override
                public void handle(MouseEvent event) {
                    label.setText(String.valueOf(data.getPieValue()) + "%");
                }
            });
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

}
