package primeriafx.atributosTaxi;
/**
 *
 * @author Alexandre
 */
public class MetodosTaxi {
    public double calculaIPVA(double valorCarro, int ipva){
		double valorIPVA = (valorCarro/100)*ipva;
		return valorIPVA;
	}
	public double calculaSeguro(double valorCarro, int seguro){
		double valorSeguro = (valorCarro/100)*seguro;
		return valorSeguro;
	}
	public double calculaEmplacamento(double valorCarro, int emplacamento){
		double valorEmpla = (valorCarro/100)*emplacamento;
		return valorEmpla;
	}
	public double calculaDepreciacao(double valorCarro, int depreciacao){
		double valorDepre = (valorCarro/100)*depreciacao;
		return valorDepre;
	}
	public double valorAnualGasolina(double precoGaso, int kilometragem, double valorCarro){
		int consumo;
		double valorTotal;
		if(valorCarro <= 30000){
			consumo = 13;
			valorTotal = ((kilometragem*200)/consumo)*precoGaso;
		}
		else if(valorCarro > 30000 && valorCarro <= 75000 ){
			consumo = 14;
			valorTotal = ((kilometragem*200)/consumo)*precoGaso;
		}
		else{
			consumo = 10;
			valorTotal = ((kilometragem*200)/consumo)*precoGaso;
		}
		return valorTotal;
	}
	public double valorAnualTaxi(double precoKmTaxi, int kilometragem, double bandeirada){
		double valorTotal = ((2*bandeirada)+precoKmTaxi*kilometragem)*200;
		return valorTotal;
	}
}