/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */
public class Economia1Controller implements Initializable {
    @FXML    
    private void voltarTelaPrincipal(ActionEvent e) throws IOException{
        Parent tela_principal_parent = FXMLLoader.load(getClass().getResource("TelaPrincipal.fxml"));
        Scene tela_principal_scene = new Scene(tela_principal_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(tela_principal_scene);
        app_stage.show();
    }
    @FXML
    private void telaPets(ActionEvent e) throws IOException{
        Parent pets1_parent = FXMLLoader.load(getClass().getResource("Pets1.fxml"));
        Scene pets1_scene = new Scene(pets1_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(pets1_scene);
        app_stage.show();
    }
    @FXML
    private void telaResidencia(ActionEvent e) throws IOException{
        Parent residencia1_parent = FXMLLoader.load(getClass().getResource("Residencia.fxml"));
        Scene residencia1_scene = new Scene(residencia1_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(residencia1_scene);
        app_stage.show();
    }
    @FXML
    private void telaOrcamento(ActionEvent e) throws IOException{
        Parent orcamento_parent = FXMLLoader.load(getClass().getResource("Orcamento.fxml"));
        Scene orcamento_scene = new Scene(orcamento_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(orcamento_scene);
        app_stage.show();
    }
    @FXML
    private void telaTaxi(ActionEvent e) throws IOException{
        Parent taxi_parent = FXMLLoader.load(getClass().getResource("TaxiCarro0.fxml"));
        Scene taxi_scene = new Scene(taxi_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(taxi_scene);
        app_stage.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
