/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */
public class GraficoController implements Initializable {
    @FXML PieChart pie;
    
    @FXML
     private void gerarGrafico(ActionEvent e) throws IOException{
          ObservableList<PieChart.Data> list = FXCollections.observableArrayList(
                new PieChart.Data("Sobrevivência", 10),
                new PieChart.Data("Supérfulos", 10),
                new PieChart.Data("Investimentos", 10)
        );
        pie.setData(list);         
     }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
