/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */
public class GraficoLinhaController implements Initializable {
    @FXML
    LineChart<String, Number> lineChart;
    
    public void gerar(ActionEvent event){
        lineChart.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<String, Number>();
        series.getData().add(new XYChart.Data<String, Number>("Jan",200));
        series.getData().add(new XYChart.Data<String, Number>("Fev",500));
        series.getData().add(new XYChart.Data<String, Number>("Mar",300));
        series.getData().add(new XYChart.Data<String, Number>("Abr",400));
        series.setName("N sei 1");
        
        XYChart.Series<String, Number> series1 = new XYChart.Series<String, Number>();
        series1.getData().add(new XYChart.Data<String, Number>("Jan",100));
        series1.getData().add(new XYChart.Data<String, Number>("Fev",600));
        series1.getData().add(new XYChart.Data<String, Number>("Mar",300));
        series1.getData().add(new XYChart.Data<String, Number>("Abr",700));
        series1.setName("N sei 2");
        lineChart.getData().addAll(series, series1);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
