/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.awt.peer.PanelPeer;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */
public class OrcamentoController implements Initializable {
   @FXML TextField seguro;
   @FXML TextField alimentacao;
   @FXML TextField transporte;
   @FXML TextField aluguel;
   @FXML TextField contas;
   @FXML TextField bruto;
   @FXML PieChart pie;
   @FXML Label label;
   @FXML AnchorPane paneGrafico;
   @FXML AnchorPane paneGeral;
   @FXML AnchorPane paneOrca;
   
   @FXML 
   private void voltarTelaPrincipal(ActionEvent e) throws IOException{
        Parent tela_principal_parent = FXMLLoader.load(getClass().getResource("Economia1.fxml"));
        Scene tela_principal_scene = new Scene(tela_principal_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(tela_principal_scene);
        app_stage.show();
    }
     @FXML
     private void gerarGrafico(ActionEvent e) throws IOException{
         paneGrafico.setVisible(true);
         paneOrca.setVisible(false);
          ObservableList<PieChart.Data> list = FXCollections.observableArrayList(
                new PieChart.Data("Sobrevivência", ((Integer.parseInt(seguro.getText())+Integer.parseInt(aluguel.getText()))*100)/Integer.parseInt(bruto.getText())),
                new PieChart.Data("Supérfulos", ((100 - ((Integer.parseInt(seguro.getText())+Integer.parseInt(aluguel.getText()))*100)/Integer.parseInt(bruto.getText()))/3)),
                new PieChart.Data("Investimentos", ((100 - ((Integer.parseInt(seguro.getText())+Integer.parseInt(aluguel.getText()))*100)/Integer.parseInt(bruto.getText()))/3)*2)
        );
        pie.setData(list);

        for(final PieChart.Data data: pie.getData()){
            data.getNode().addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>(){
              @Override
                public void handle(MouseEvent event){
                  label.setText(String.valueOf(data.getPieValue())+ "%");
              }  
            });
            
        }
     }
     
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
