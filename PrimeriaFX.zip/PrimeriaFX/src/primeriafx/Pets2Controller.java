/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */
public class Pets2Controller implements Initializable {
    @FXML private Button voltarButton;
    @FXML private TextField peso;
    @FXML private TextField frequencia;
    @FXML private TextField precoFilhote;
    @FXML private TextField precoRacao;
    @FXML private Label mensal;
    @FXML private Label primeiroAno;
    @FXML private Label gastoAnual;
    @FXML private Label total;
    @FXML private CheckBox castracao;
    
    public double calculaConsumoRacao(double peso, double precoRacao){
        double consumoMensal = 0;
        if(peso < 6.8){
            consumoMensal = (1.5*precoRacao) + 180;
        }else if(peso > 6.8 && peso < 9.1 ){
            consumoMensal = (9*precoRacao) + 120;
        }else if (peso > 9.1){ 
            consumoMensal = (15*precoRacao) + 140;
        }
            return consumoMensal;
    }   
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
    }    
    
}
