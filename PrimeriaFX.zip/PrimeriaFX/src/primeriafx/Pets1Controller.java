/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */

public class Pets1Controller implements Initializable{
    
    public double calculaConsumoRacao(double peso, double precoRacao){
        double consumoMensal = 0;
        if(peso < 6.8){
            consumoMensal = (1.5*precoRacao) + 180;
        }else if(peso > 6.8 && peso < 9.1 ){
            consumoMensal = (9*precoRacao) + 120;
        }else if (peso > 9.1){ 
            consumoMensal = (15*precoRacao) + 140;
        }
            return consumoMensal;
    }
    public void limparText(TextField campo){
        campo.setText("");
    }
    public void limparLabel(Label label){
        label.setText("");
    }
    
    @FXML private Button voltarButton;
    @FXML private TextField peso;
    @FXML private TextField frequencia;
    @FXML private TextField precoFilhote;
    @FXML private TextField precoRacao;
    @FXML private Label mensal;
    @FXML private Label primeiroAno;
    @FXML private Label gastoAnual;
    @FXML private Label total;
    @FXML private CheckBox castracao;
    @FXML private Pane painel;
    @FXML private Pane painel1;
    @FXML private RadioButton porteP;
    @FXML private RadioButton porteM;
    @FXML private RadioButton porteG;
    @FXML private CheckBox nPagaPet;
    
 private double calculaConsumoRacao(double precoRacao){
     double kg = 0;
     double consumo;
     if(porteP.isSelected()){
        kg = 2;
     }
     if(porteM.isSelected()){
         kg = 3;
     }
     if(porteG.isSelected()){
         kg = 4;
     }
     consumo = (kg*precoRacao)*12;
     return consumo;
 }
 
 private double gastosPetShop(double frequenciaVet){
     //Estabelecer o preço dos banhos
     int nBanhos = 0;
     double precoBanho = 0;
     double totalPet;
     if(porteP.isSelected()){
        nBanhos = 4;
        precoBanho = 10;
     }
     if(porteM.isSelected()){
         nBanhos = 4;
         precoBanho = 15;
     }
     if(porteG.isSelected()){
         nBanhos = 2;
         precoBanho = 20;
     }
     totalPet = ((nBanhos*precoBanho)*12)+(frequenciaVet*50);
     return totalPet;
 }

@FXML   private void voltar(ActionEvent e) throws IOException{
        Parent tela_principal_parent = FXMLLoader.load(getClass().getResource("Economia1.fxml"));
        Scene tela_principal_scene = new Scene(tela_principal_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(tela_principal_scene);
        app_stage.show();
    }
    
@FXML  private void calcular(ActionEvent e) throws IOException{
        double consumoPetShop=0;
        double consumoRacao = calculaConsumoRacao( Double.parseDouble(precoRacao.getText()));
        if(nPagaPet.isSelected()){            
        consumoPetShop = (Double.parseDouble(frequencia.getText())*50);
        }else{
        consumoPetShop = gastosPetShop(Double.parseDouble(frequencia.getText()));
        }
        double primeiroAnoTotal = Double.parseDouble(precoFilhote.getText())+ 200 + 
                (consumoRacao/2) + (consumoPetShop/2);
        if(castracao.isSelected()){
            primeiroAnoTotal = primeiroAnoTotal+200;
            //consumoAno = consumoAno+200;
        }
        double totalTudo = 0;
        if(porteP.isSelected()){
            totalTudo = ((consumoRacao+consumoPetShop)*6) + primeiroAnoTotal;
        }
        if(porteM.isSelected()){
            totalTudo = ((consumoRacao+consumoPetShop)*9) + primeiroAnoTotal;
        }
        if(porteG.isSelected()){
            totalTudo = ((consumoRacao+consumoPetShop)*14) + primeiroAnoTotal;
        }
        double consumo = (consumoPetShop+consumoRacao)/12;
        painel1.setVisible(false);
        painel.setVisible(true);
        mensal.setText("R$ " + String.valueOf(Math.floor(consumo)));
        gastoAnual.setText("R$ " + String.valueOf(consumoPetShop+consumoRacao));
        primeiroAno.setText("R$ " + String.valueOf(primeiroAnoTotal));
        total.setText("R$ " + String.valueOf(totalTudo));
    }
@FXML private void limparCampos(ActionEvent e) throws IOException{
    painel1.setVisible(true);
        painel.setVisible(false);
    limparLabel(mensal);
    limparLabel(primeiroAno);
    limparLabel(gastoAnual);
    limparLabel(total);
    limparText(frequencia);
    limparText(precoFilhote);
    limparText(precoRacao);
    castracao.setSelected(false);
    nPagaPet.setSelected(false);
    porteP.setSelected(false);
    porteM.setSelected(false);
    porteG.setSelected(false);
}
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}