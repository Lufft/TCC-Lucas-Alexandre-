/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeriafx;

import java.awt.Panel;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import primeriafx.atributosTaxi.MetodosTaxi;

/**
 * FXML Controller class
 *
 * @author Alexandre
 */ 
public class TesteTaxiController implements Initializable {
    @FXML AnchorPane ancoraR;
    @FXML TextField ipva;
    @FXML TextField kilometragem;
    @FXML TextField precoCarro;
    @FXML TextField precoGaso;
    @FXML TextField precoKmTaxi;
    @FXML TextField bandeirada;
    @FXML TextField depreciacao;
    @FXML TextField manuntencao;
    @FXML TextField seguro;
    @FXML TextField emplacamento;    
    @FXML Label campoFinalTaxi;
    @FXML Label campoFinalCarro;
  
    @FXML    
    private void voltarEconomia(ActionEvent e) throws IOException{
        Parent tela_principal_parent = FXMLLoader.load(getClass().getResource("Economia1.fxml"));
        Scene tela_principal_scene = new Scene(tela_principal_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.setScene(tela_principal_scene);
        app_stage.show();
    }
    @FXML
    private void calcular(ActionEvent e ) throws IOException{
        ancoraR.setVisible(true);
        MetodosTaxi met = new  MetodosTaxi();
    double valorIpva = met.calculaIPVA(Double.parseDouble(precoCarro.getText()),
            Integer.parseInt(ipva.getText()));
    double valorseguro = met.calculaSeguro(Double.parseDouble(precoCarro.getText()),
            Integer.parseInt(seguro.getText()));
    double valorEmplacamento = met.calculaEmplacamento(Double.parseDouble(precoCarro.getText()),
            Integer.parseInt(emplacamento.getText()));
    double valorConsumoCarro = met.valorAnualGasolina(Double.parseDouble(precoGaso.getText()),
            Integer.parseInt(kilometragem.getText()),Double.parseDouble(precoCarro.getText()));
    double valorConsumoTaxi = met.valorAnualTaxi(Double.parseDouble(precoKmTaxi.getText()),Integer.parseInt(kilometragem.getText()),
            Double.parseDouble(bandeirada.getText()));
    double valorDepreciaçao = met.calculaDepreciacao(Double.parseDouble(precoCarro.getText()), Integer.parseInt(depreciacao.getText()));
    
    double consumoGeralCarro = valorIpva+valorseguro+valorEmplacamento+valorConsumoCarro+ valorDepreciaçao +Double.parseDouble(manuntencao.getText());
    campoFinalCarro.setText("R$ " + String.valueOf(consumoGeralCarro));
    campoFinalTaxi.setText("R$ " + String.valueOf(valorConsumoTaxi));
    }
    @FXML
    private void fechar(ActionEvent e ) throws IOException{
        ancoraR.setVisible(false);
    }
    @FXML private void limpar(ActionEvent e) throws IOException{
    ipva.setText("");
    kilometragem.setText("");
    precoCarro.setText("");
    precoGaso.setText("");
    precoKmTaxi.setText("");
    bandeirada.setText("");
    depreciacao.setText("");
    manuntencao.setText("");
    seguro.setText("");
    emplacamento.setText("");    
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}